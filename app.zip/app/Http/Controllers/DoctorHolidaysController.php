<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DoctorHolidaysController extends Controller
{
    //
}
